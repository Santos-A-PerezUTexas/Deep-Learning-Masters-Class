git add *.py
git commit -m "Update"
git push
